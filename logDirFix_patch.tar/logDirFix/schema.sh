#!/bin/sh
BASE_PATH=$(cd "$(dirname "$0")"; pwd)
HDP_PATH="/usr/hdp/2.4.2.0-258"
DATABUS_PATH="/usr/hdp/2.4.2.0-258/databus"

OWN=hdfs:hadoop

export JAVA_HOME=/usr/jdk64/jdk1.7.0_67/

deploy_install(){
        cd $BASE_PATH

        cd ../
        if [ ! -d $DATABUS_PATH ];then
          tar -zxvf databus.tar.gz -C $HDP_PATH/
        fi
        chown -R $OWN $HDP_PATH/databus

        DATABUS_PIDDIR="/var/run/databus"
        if [ ! -d $DATABUS_PIDDIR ];then
           mkdir $DATABUS_PIDDIR
        fi
        chown -R $OWN $DATABUS_PIDDIR
}

deploy_uninstall(){
        if [! -d $DATABUS_PATH]; then
        rm -rf $DATABUS_PATH
        fi
        #echo "-----------卸载------------">> /var/run/databus/databus.log
}

deploy_start(){
        cd $DATABUS_PATH/

        DATABUS_PIDDIR="/var/run/databus"
        if [ ! -d $DATABUS_PIDDIR ];then
           mkdir $DATABUS_PIDDIR
        fi
        chown -R $OWN $DATABUS_PIDDIR
	
su hdfs <<EOF
        sh bin/read.sh
        sh bin/start-kafka.sh schema
EOF
}

deploy_stop(){
    cd $DATABUS_PATH/
su hdfs <<EOF
    sh bin/stop-kafka.sh schema
EOF
}

deploy_status(){
su hdfs <<EOF
        count=`ps -ef |grep SchemaRegistryMain | grep -v grep |awk '{print $2}'`
        if [$count >0]
        then
        schema_pid=`ps -ef |grep SchemaRegistryMain | grep -v grep |awk '{print $2}'`
                #echo schema_pid >/var/run/databus/schema.pid
        else
                echo "没有启动"
        fi
EOF
}

case $1 in
        inconfig) deploy_config;;
        install) deploy_install;;
        installKafka) deploy_install;;
        uninstall) deploy_uninstall;;
        start) deploy_start;;
        stop) deploy_stop;;
        status) deploy_status;;
        test) deploy_test;;
esac
                                           