#!/bin/sh

AGENT_PATH="/var/lib/ambari-agent/cache/stacks/HDP/2.4/services/DATABUS/package/scripts/"
SERVER_PATH="/var/lib/ambari-server/resources/stacks/HDP/2.4/services/DATABUS/package/scripts/"
basepath=$(cd `dirname $0`; pwd)
#echo $basepath

if [ -d $AGENT_PATH ];then
	cp -f $basepath/kafka.sh $AGENT_PATH
	cp -f $basepath/schema.sh $AGENT_PATH
	cp -f $basepath/connect.sh $AGENT_PATH
fi
if [ -d $SERVER_PATH ];then
	cp -f $basepath/kafka.sh $SERVER_PATH
	cp -f $basepath/schema.sh $SERVER_PATH
	cp -f $basepath/connect.sh $SERVER_PATH
fi
